Material Base v2
================

INTRODUCTION
------------

**Material Base** — is a base theme for Drupal 9+.
It implements Material Design concept by Google.

Read **[documentation](docs/index.md)** to get started.

Happy theming!

REQUIREMENTS
------------

This theme requires no modules outside of Drupal core.

INSTALLATION
------------

Read **[Install section](docs/install.md)** of documentation.


CONFIGURATION
-------------

Read **[Setup section](docs/setup.md)** of documentation.
