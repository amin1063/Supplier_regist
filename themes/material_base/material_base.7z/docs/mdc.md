MDC subtheme and MDC library
============================

[Material Components for web](https://material.io/develop/web) library implemented in Material Base as a subtheme that contains CSS, JS, twig templates and functions dependent on this library.
In theory, it could be replaced by other libraries, custom implementations, new versions of MDC library, or something else. Material Base v2 was developed in mind with using of this subtheme is a common case but using without it is also possible.

<!-- TODO: add info about MB components dependent on MDC -->
