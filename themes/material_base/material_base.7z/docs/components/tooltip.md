Tooltip
=======

Material Base provides style for the tooltip.

Tooltip displaying behaviour wasn't implemented yet.

Component implemented as CSS classes for using in markup.

Component classes
-----------------

`tooltip` - tooltip element.

Examples of usage
-----------------

~~~
<div class="tooltip">
  Tooltip text
</div>
~~~
