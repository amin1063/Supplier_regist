Place images used in styles here. Subfolders also could be used.
