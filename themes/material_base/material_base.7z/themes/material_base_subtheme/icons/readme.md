Place SVG files for generating SVG icons sprite here.
